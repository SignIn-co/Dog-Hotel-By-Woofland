(function(){
'use strict';
var D=document,root=D.documentElement;root.classList.add('js');
var $=function(s,c){return (c||D).querySelector(s)},$$=function(s,c){return [].slice.call((c||D).querySelectorAll(s))};
var clamp=function(x,a,b){return Math.max(a===undefined?0:a,Math.min(b===undefined?1:b,x))};
var seg=function(a,b,x){return clamp((x-a)/(b-a))},lerp=function(a,b,t){return a+(b-a)*t};
var reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
var fine=window.matchMedia&&matchMedia('(pointer:fine)').matches;
var S={y:0,sy:window.scrollY||0,vh:innerHeight,vw:innerWidth,svel:0};
function top(el){return el.getBoundingClientRect().top+(window.scrollY||0)}

/* word split */
function split(el){var out=[];(function walk(node){[].slice.call(node.childNodes).forEach(function(n){
  if(n.nodeType===3){var f=D.createDocumentFragment();n.textContent.split(/(\s+)/).forEach(function(t){if(!t)return;if(/^\s+$/.test(t)){f.appendChild(D.createTextNode(' '));return}var s=D.createElement('span');s.className='w';s.textContent=t;f.appendChild(s);out.push(s)});node.replaceChild(f,n)}
  else if(n.nodeType===1)walk(n)})})(el);return out}

/* nav + menu */
var nav=$('#nav'),pill=$('.navpill'),blob=pill&&$('.blob',pill);
if(pill&&fine){$$('a',pill).forEach(function(a){a.addEventListener('mouseenter',function(){blob.style.opacity=1;blob.style.width=a.offsetWidth+'px';blob.style.transform='translateX('+a.offsetLeft+'px)'})});pill.addEventListener('mouseleave',function(){blob.style.opacity=0})}
var burger=$('#burger');
var menuEl=$('#menu');
function setMenu(o,noFocus){if(!menuEl)return;root.classList.toggle('menu-open',o);burger.setAttribute('aria-expanded',o);D.body.style.overflow=o?'hidden':'';
  menuEl.inert=!o;menuEl.setAttribute('aria-hidden',o?'false':'true');
  $$('body > main, body > footer, #runner, #nav .navpill, #nav .brand, #nav .login, #nav .right > .btn').forEach(function(el){el.inert=o});
  if(noFocus)return;if(o){setTimeout(function(){menuEl.focus({preventScroll:true})},60)}else burger.focus({preventScroll:true})}
if(burger&&menuEl){menuEl.tabIndex=-1;menuEl.inert=true;menuEl.setAttribute('aria-hidden','true');
  burger.addEventListener('click',function(){setMenu(!root.classList.contains('menu-open'))});
  $$('.menu a').forEach(function(a){a.addEventListener('click',function(){setMenu(false,true)})});
  D.addEventListener('keydown',function(e){if(e.key==='Escape'&&root.classList.contains('menu-open')){e.preventDefault();setMenu(false)}});
  var sx=0,sy0=0;menuEl.addEventListener('touchstart',function(e){sx=e.touches[0].clientX;sy0=e.touches[0].clientY},{passive:true});
  menuEl.addEventListener('touchend',function(e){var dx=e.changedTouches[0].clientX-sx,dy=e.changedTouches[0].clientY-sy0;if((dx>80&&Math.abs(dx)>Math.abs(dy)*1.3)||(dy<-90&&Math.abs(dy)>Math.abs(dx)*1.3&&menuEl.scrollHeight<=menuEl.clientHeight+2))setMenu(false)},{passive:true})}

/* cursor + magnetic */
var cur=$('#cur'),mouse={x:.5,y:.5,tx:.5,ty:.5,px:-100,py:-100};
window.addEventListener('pointermove',function(e){mouse.px=e.clientX;mouse.py=e.clientY;mouse.tx=e.clientX/S.vw;mouse.ty=1-e.clientY/S.vh},{passive:true});
if(fine&&cur){
  $$('a,button').forEach(function(a){a.addEventListener('mouseenter',function(){cur.classList.add('big')});a.addEventListener('mouseleave',function(){cur.classList.remove('big')})});
  $$('.mag').forEach(function(b){b.addEventListener('mousemove',function(e){var r=b.getBoundingClientRect();b.style.transform='translate('+((e.clientX-r.left-r.width/2)*.25)+'px,'+((e.clientY-r.top-r.height/2)*.35)+'px)'});
    b.addEventListener('mouseleave',function(){b.style.transition='transform .6s cubic-bezier(.16,1,.3,1)';b.style.transform='';setTimeout(function(){b.style.transition=''},600)})});
}

/* reveals + counters */
function count(el){var to=parseFloat(el.dataset.count),dec=+(el.dataset.dec||0),st=performance.now();(function f(now){var k=clamp((now-st)/1700),e=1-Math.pow(1-k,4);el.textContent=(to*e).toFixed(dec);if(k<1)requestAnimationFrame(f)})(st)}
if('IntersectionObserver' in window){
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);if(e.target.dataset.count!==undefined)count(e.target)}})},{threshold:.2});
  $$('[data-in],[data-count],.clip').forEach(function(el){io.observe(el)});
}else{$$('[data-in],.clip').forEach(function(el){el.classList.add('in')})}

/* story words */
var qEl=$('#storyq'),qWords=qEl?split(qEl):[];qWords.forEach(function(w){if(/backyard|relaxed|safe|happy/.test(w.textContent))w.classList.add('hot')});
var maniDog=$('#maniDog'),reel=$('#reel'),rtrack=$('#rtrack'),panels=$$('.panel'),rcnt=$('#rcnt');

/* marquee */
var mq=$('#mq1');if(mq){var h='';for(var r=0;r<6;r++)h+='<span>Dog Daycare</span><span>Dog Hotel</span>';mq.innerHTML=h}

/* stars in night */
var stars=$('.night .stars');if(stars){var sh='';for(var i=0;i<46;i++)sh+='<i style="left:'+(Math.random()*100).toFixed(1)+'%;top:'+(Math.random()*58).toFixed(1)+'%;animation-delay:'+(Math.random()*4).toFixed(2)+'s"></i>';stars.innerHTML=sh}

/* reviews wall: duplicate columns for seamless loop */
$$('.wall .col').forEach(function(c){c.innerHTML+=c.innerHTML});
var wcols=$$('.wall .col'),wallEl=$('.wall'),wpb=$('#wpause'),wOff=0,wLast=0,wPaused=reduce,wHover=false,wSeen=false;
function wSet(p){wPaused=p;if(wpb){wpb.setAttribute('aria-pressed',p);wpb.classList.toggle('on',p);wpb.querySelector('span').textContent=p?'Play reviews':'Pause reviews'}}
function wallTick(now){var dt=wLast?Math.min(.1,(now-wLast)/1000):0;wLast=now;if(!wPaused&&!wHover&&wSeen){wOff+=dt;for(var i=0;i<wcols.length;i++){var c=wcols[i],half=c.scrollHeight/2+8,sp=[22,18,16][i%3],o=(wOff*sp)%half;c.style.transform='translate3d(0,'+(i%2?-(half-o):-o).toFixed(1)+'px,0)'}}requestAnimationFrame(wallTick)}
if(wcols.length){wSet(wPaused);if(wpb)wpb.addEventListener('click',function(){wSet(!wPaused)});
  if(fine){wallEl.addEventListener('mouseenter',function(){wHover=true});wallEl.addEventListener('mouseleave',function(){wHover=false})}
  if('IntersectionObserver' in window)new IntersectionObserver(function(es){wSeen=es[0].isIntersecting},{rootMargin:'100px'}).observe(wallEl);else wSeen=true;
  requestAnimationFrame(wallTick)}
var skipB=$('#skip');if(skipB)skipB.addEventListener('click',function(){var m=$('.mq')||$('#reel');if(m)window.scrollTo({top:m.getBoundingClientRect().top+(window.scrollY||0),behavior:'smooth'})});

/* film strip */
var strip=$('#strip'),film={x:0,v:0,drag:false,lx:0,w:0};
if(strip){strip.innerHTML+=strip.innerHTML;
  strip.addEventListener('pointerdown',function(e){film.drag=true;film.lx=e.clientX;strip.setPointerCapture(e.pointerId);strip.style.cursor='grabbing'});
  strip.addEventListener('pointermove',function(e){if(!film.drag)return;var d=e.clientX-film.lx;film.lx=e.clientX;film.x+=d;film.v=d});
  var end=function(){film.drag=false;strip.style.cursor='grab'};strip.addEventListener('pointerup',end);strip.addEventListener('pointercancel',end);}

/* faq */
$$('.qa button').forEach(function(b){b.addEventListener('click',function(){var q=b.parentNode,o=q.classList.contains('open');$$('.qa.open').forEach(function(x){x.classList.remove('open');$('button',x).setAttribute('aria-expanded','false')});if(!o){q.classList.add('open');b.setAttribute('aria-expanded','true')}})});
$$('.chips button').forEach(function(c){c.addEventListener('click',function(){$$('.chips button').forEach(function(x){x.classList.toggle('on',x===c)});var cat=c.dataset.cat;$$('.qa').forEach(function(q){q.hidden=!(cat==='all'||q.dataset.cat===cat)})})});

/* rooms hover float */
var rfloat=$('#rfloat'),rf={x:0,y:0,on:false,rot:0};
if(rfloat&&fine){var rfi=$$('img',rfloat);$$('.room[data-room]').forEach(function(r){
  r.addEventListener('mouseenter',function(){var i=+r.dataset.room;rf.on=true;rfloat.classList.add('on');rfi.forEach(function(im,k){im.classList.toggle('on',k===i)})});
  r.addEventListener('mouseleave',function(){rf.on=false;rfloat.classList.remove('on')})})}

/* WebGL hero (home) */
var canvas=$('#gl'),gl=null,U={},tex=[],tsize=[],hero=$('#hero'),hframe=$('#hframe'),hfall=$('#hfall'),
    slides=$$('.hslide'),hill=$('#hill'),hstory=$('#hstory'),htrack=$('#htrack'),hdog=$('#hdog'),hleash=$('#hleashp'),hclip=$('#hclip'),hbone=$('#hbone'),hspr=$('#hspr'),hslp=$('#hslp'),hsun=$('.hsun'),hstage=$('.hstage'),hdp={},hst={},hpose='walk',dots=$$('.hmeta .dots i'),hnum=$('#hnum'),curSlide=-2,ready=!hero,started=!hero,
    heroSrc=hero?hero.dataset.src.split(','):[],heroFy=hero?hero.dataset.fy.split(',').map(Number):[];
var VS='attribute vec2 p;varying vec2 v;void main(){v=p*.5+.5;gl_Position=vec4(p,0.,1.);}';
var FS=['precision highp float;varying vec2 v;uniform sampler2D t0,t1;uniform vec2 res,s0,s1,mouse,fy;uniform float pr,time,vel;',
'float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}',
'float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1,0)),f.x),mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x),f.y);}',
'float fbm(vec2 p){float a=.5,s=0.;for(int i=0;i<4;i++){s+=a*n(p);p*=2.03;a*=.5;}return s;}',
'vec2 cov(vec2 uv,vec2 img,float f){float ra=res.x/res.y,ia=img.x/img.y;vec2 sc=ra>ia?vec2(1.,ia/ra):vec2(ra/ia,1.);vec2 c=(uv-.5)*sc+.5;c.y+=(f-.5)*(1.-sc.y);return c;}',
'vec3 samp(sampler2D t,vec2 uv,vec2 sz,float f,float sh){vec2 c=cov(uv,sz,f);return vec3(texture2D(t,c+vec2(sh,0.)).r,texture2D(t,c).g,texture2D(t,c-vec2(sh,0.)).b);}',
'void main(){vec2 uv=v;float asp=res.x/res.y;',
' float nz=fbm(uv*vec2(asp,1.)*2.4+time*.03);float th=nz*.7+(1.-uv.y)*.3;float m=smoothstep(th-.1,th+.1,pr*1.2-.1);',
' float z0=1.-pr*.06;float z1=1.06-pr*.06;',
' vec2 u0=(uv-.5)*z0+.5+vec2(0.,pr*.05);vec2 u1=(uv-.5)*(1./z1)+.5-vec2(0.,(1.-pr)*.05);',
' float w=(nz-.5)*.07;u0+=w*m;u1-=w*(1.-m);float sh=0.;',
' vec3 a=samp(t0,u0,s0,fy.x,sh),b=samp(t1,u1,s1,fy.y,sh);vec3 c=mix(a,b,m);',
' float band=smoothstep(0.,.5,m)*smoothstep(1.,.5,m);c+=vec3(1.,.52,.1)*band*.5;',
' float vg=smoothstep(1.25,.25,length((v-.5)*vec2(1.1,1.)));c*=mix(.92,1.,vg);',
' gl_FragColor=vec4(c,1.);}'].join('\n');
function initGL(){
  if(!canvas)return false;
  try{gl=canvas.getContext('webgl',{antialias:false,alpha:false})}catch(e){gl=null}
  if(!gl)return false;
  try{var pg=gl.createProgram();[[gl.VERTEX_SHADER,VS],[gl.FRAGMENT_SHADER,FS]].forEach(function(a){var s=gl.createShader(a[0]);gl.shaderSource(s,a[1]);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));gl.attachShader(pg,s)});
    gl.linkProgram(pg);if(!gl.getProgramParameter(pg,gl.LINK_STATUS))throw new Error('link');gl.useProgram(pg);
    var b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
    var loc=gl.getAttribLocation(pg,'p');gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);
    ['t0','t1','res','s0','s1','mouse','fy','pr','time','vel'].forEach(function(k){U[k]=gl.getUniformLocation(pg,k)});gl.uniform1i(U.t0,0);gl.uniform1i(U.t1,1);
  }catch(e){gl=null;return false}
  return true;
}
function mkTex(img,i){var t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);tex[i]=t;tsize[i]=[img.naturalWidth,img.naturalHeight]}
var glok=hero?initGL():false;
function sizeGL(){if(!glok)return;var dpr=Math.min(window.devicePixelRatio||1,2),r=canvas.getBoundingClientRect(),w=Math.max(2,Math.round(r.width*dpr)),hh=Math.max(2,Math.round(r.height*dpr));if(canvas.width!==w||canvas.height!==hh){canvas.width=w;canvas.height=hh;gl.viewport(0,0,w,hh)}}
function setSlide(i,force){if(!ready)return;if(i===curSlide&&!force)return;curSlide=i;slides.forEach(function(s,k){s.classList.toggle('on',k===i)});if(i>=0){dots.forEach(function(d,k){d.classList.toggle('on',k===i)});hnum.textContent='0'+(i+1)}}

/* loader (home) */
var loader=$('#loader'),runner=$('#runner');
if(hero&&loader){
  var lcount=$('#lcount'),lbar=$('#lbar'),loaded=0,shown=0,t0=performance.now();
  hfall.style.backgroundImage='url('+heroSrc[0]+')';
  heroSrc.forEach(function(src,i){var im=new Image();im.crossOrigin='anonymous';im.onload=function(){if(glok){try{mkTex(im,i)}catch(e){}}loaded++};im.onerror=function(){loaded++};im.src=src});
  var startNow=function(){if(started)return;started=true;if(!glok||!tex[0])canvas.style.display='none';else hfall.style.display='none';loader.classList.add('done');setTimeout(function(){ready=true;setSlide(0,true);runner&&runner.classList.add('show')},reduce?0:450)};
  (function tick(){var target=Math.min(100,loaded/heroSrc.length*100),el=performance.now()-t0;if(el>4500)target=100;shown+=(target-shown)*.12+(target>shown?.5:0);if(shown>target)shown=target;
    lcount.textContent=Math.round(shown);lbar.style.transform='scaleX('+(shown/100)+')';if(shown>=99.5&&el>800)startNow();else requestAnimationFrame(tick)})();
  setTimeout(startNow,7000);
}else{runner&&runner.classList.add('show');$$('.phero').forEach(function(p){setTimeout(function(){p.classList.add('in')},60)})}

/* runner */
var rdog=$('#rdog'),rfill=$('#rfill'),rspr=$('#rspr'),rslp=$('#rslp'),rph=0,rfr=-1,poses={},pose='sit',flip=1,idleAt=performance.now(),lastY=window.scrollY||0,spd=0;
if(rdog)$$('img',rdog).forEach(function(i){poses[i.dataset.p]=i});
function setPose(p){if(p===pose||!poses[p])return;poses[pose].classList.remove('on');poses[p].classList.add('on');pose=p}

/* footer word: letters rise under the pointer, a dog runs along the top */
var gw=$('.foot .giant'),fdog=$('.foot .fdog');
if(gw){var txt=gw.textContent;gw.textContent='';var letters=txt.split('').map(function(c){var s=D.createElement('span');s.textContent=c;gw.appendChild(s);return s});
  var wave=function(cx){var r=gw.getBoundingClientRect();letters.forEach(function(s){var b=s.getBoundingClientRect(),d=Math.abs(cx-(b.left+b.width/2))/(r.width*.22),k=Math.max(0,1-d);k=k*k*(3-2*k);
      s.style.transform='translateY('+(-k*16).toFixed(1)+'%) scaleY('+(1+k*.16).toFixed(3)+') rotate('+((cx<b.left+b.width/2?-1:1)*k*3).toFixed(2)+'deg)';s.classList.toggle('hot',k>.25)});
    if(fdog){fdog.style.opacity=1;fdog.style.transform='translate3d('+(cx-r.left-fdog.offsetWidth/2).toFixed(1)+'px,'+(-gw.offsetHeight*.93)+'px,0) scaleX('+(cx<(wave.lx||0)?1:-1)+')';wave.lx=cx}};
  var calm=function(){letters.forEach(function(s){s.style.transform='';s.classList.remove('hot')});if(fdog)fdog.style.opacity=0};
  gw.addEventListener('pointermove',function(e){wave(e.clientX)});gw.addEventListener('pointerleave',calm);gw.addEventListener('pointercancel',calm);}

/* measure */
var pars=$$('[data-par]'),M={},ctaWord=$('#ctaWord'),giant=$('.foot .giant'),bgw=$('.phero .bgw'),bigs=$$('.big');
var lastW=0,lastH=0;function onResize(){var w=innerWidth,h=innerHeight;if(!fine&&w===lastW&&Math.abs(h-lastH)<lastH*.3)return;measure()}
function measure(){lastW=innerWidth;lastH=innerHeight;S.vh=innerHeight;S.vw=innerWidth;if(htrack){htrack._S=0;hstory._H=0;hstory._lead=innerWidth<900?.1:.25}
  if(reel){reel.style.height=(S.vw<900?panels.length*75+25:panels.length*85+30)+'vh';}
  if(hero)M.hero={t:top(hero),h:hero.offsetHeight,s:hstage.offsetHeight||innerHeight};
  if(reel)M.reel={t:top(reel),h:reel.offsetHeight,w:rtrack.scrollWidth};
  if(qEl)M.q={t:top(qEl),h:qEl.offsetHeight};
  M.par=pars.map(function(p){var b=p.closest('[data-parbox]')||p.parentNode;return {t:top(b),h:b.offsetHeight,k:+p.dataset.par}});
  if(ctaWord){var c=ctaWord.parentNode;M.cta={t:top(c),h:c.offsetHeight}}
  if(strip){film.w=strip.scrollWidth/2;M.film={t:top(strip)}}
  M.big=bigs.map(function(b){return {t:top(b.parentNode)+b.offsetTop- (parseFloat(getComputedStyle(b).top)||0),h:b.offsetHeight}});
  M.doc=Math.max(1,root.scrollHeight-S.vh);sizeGL()}

/* loop */
var navY=0,T0=performance.now(),HP=-1,lastNow=T0;
function frame(now){requestAnimationFrame(frame);
  var t=(now-T0)/1000;S.y=window.scrollY||0;S.sy=reduce?S.y:lerp(S.sy,S.y,.11);if(Math.abs(S.y-S.sy)<.05)S.sy=S.y;
  S.svel=lerp(S.svel,clamp((S.y-S.sy)/120,-1.5,1.5),.2);var vh=S.vh,vw=S.vw;
  if(nav){if(S.y>navY+6&&S.y>vh*.5)nav.classList.add('hide');else if(S.y<navY-6)nav.classList.remove('hide');navY=S.y}
  mouse.x=lerp(mouse.x,mouse.tx,.05);mouse.y=lerp(mouse.y,mouse.ty,.05);
  if(fine&&cur)cur.style.transform='translate3d('+mouse.px+'px,'+mouse.py+'px,0)';

  var fdt=now-lastNow;lastNow=now;if(hero&&M.hero&&S.sy>=M.hero.t+M.hero.h)HP=-1;
  if(hero&&M.hero&&S.sy<M.hero.t+M.hero.h){
    var hpT=clamp((S.sy-M.hero.t)/(M.hero.h-M.hero.s)),hp;if(fine||reduce||HP<0)HP=hpT;else{var dt=Math.max(0,Math.min(.05,fdt/1000)),cap=(HP<.46?.075:.3)*dt,d=hpT-HP;HP+=clamp(d,-cap,cap)}hp=HP;var P=seg(.46,.6,hp)+seg(.72,.86,hp),idx=P>=1?1:0,f=P-idx;if(P>=2){idx=1;f=1}
    var si=P<.3?0:(P>.72&&P<1.3)?1:(P>1.72?2:-1);if(hp>.965)si=-1;setSlide(si);
    if(hill){var hk=clamp(P),he=hk*hk*(3-2*hk),hs=hstage.getBoundingClientRect(),sr=hsun.getBoundingClientRect(),cx=sr.left+sr.width/2-hs.left,cy=sr.top+sr.height/2-hs.top,
      mr=Math.sqrt(Math.pow(Math.max(cx,hs.width-cx),2)+Math.pow(Math.max(cy,hs.height-cy),2))+4;
      hill.style.setProperty('--hole',(he*mr).toFixed(1)+'px');hill.style.visibility=hk>=1?'hidden':'';hstory.style.visibility=hk>=1?'hidden':'';hstage.classList.toggle('onphoto',hk>.45);if(skipB)skipB.classList.toggle('gone',hp>.42);
      hstory.style.opacity=(1-seg(.15,.7,hk)).toFixed(3);
      var st=seg(0,.44,hp),Sp=htrack._S||(htrack._S=parseFloat(getComputedStyle(htrack).getPropertyValue('--S'))*vw/100),Hh=hstory._H||(hstory._H=hstory.querySelector('.hp').getBoundingClientRect().height);
      if(!hst.E){hst.E=$('#hE');hst.M=$('#hM');hst.T=$('#hT');hst.C=$('#hC');hst.ball=$('#hball')}
      var kf=function(K,s){if(s<=K[0][0])return K[0][1];for(var i=0;i<K.length-1;i++){if(s<=K[i+1][0]){var u=(s-K[i][0])/(K[i+1][0]-K[i][0]);u=u*u*(3-2*u);return K[i][1]+(K[i+1][1]-K[i][1])*u}}return K[K.length-1][1]};
      var dX=kf([[0,0],[.087,.72],[.141,.72],[.322,2.22],[.383,2.22],[.503,3.22],[.564,3.22],[.671,4.12],[.765,5.32],[.866,6.12],[.946,6.5]],st),cX=6.5,
          eX=.75+.15*dX,mX=dX<2.22?1.687+.15*dX:dX<=3.22?dX-.2:3.02+.15*(dX-3.22),tX=3.752+.15*dX,
          cam=dX+hstory._lead,camE=seg(.9,.99,st);cam=cam+(cX-cam)*camE*camE*(3-2*camE);
      var cyc=.56*Hh/Sp,gdt=Math.max(0,Math.min(.05,fdt/1000)),gdx=hst.pdX==null?0:Math.abs(dX-hst.pdX);hst.pdX=dX;
      hst.wph=(hst.wph||0)+Math.min(gdx/cyc,gdt*1.7);hst.rph=(hst.rph||0)+Math.min(gdx/(cyc*1.5),gdt*2.3);hst.hph=(hst.hph||0)+Math.min(gdx/(cyc*1.6),gdt*1.1);
      var wf=(Math.floor(hst.wph*8)%8+8)%8,rnf=9+(Math.floor(hst.rph*6)%6+6)%6,fr,ps,
          sitf=function(a,b){var q=seg(a,b,st);return q<.3?22+Math.min(5,Math.floor(q/.3*6)):q<.72?27:28+Math.min(5,Math.floor((q-.72)/.28*6))};
      if(st<.087){ps='walk';fr=wf}else if(st<.141){ps='sniff';fr=16+Math.min(5,Math.floor(seg(.087,.141,st)*6))}else if(st<.32){ps='walk';fr=wf}
      else if(st<.385){ps='sit';fr=sitf(.32,.385)}else if(st<.501){ps='walk';fr=wf}else if(st<.566){ps='sit';fr=sitf(.501,.566)}
      else if(st<.671){ps='walk';fr=wf}else if(st<.765){ps='run';fr=rnf}else if(st<.866){ps='walk';fr=wf}
      else if(st<.946){ps='jump';var jq0=seg(.866,.946,st);fr=jq0<.3?35+Math.floor(jq0/.3*2):jq0<.6?37:38}else{ps='sleep';fr=38}
      var lap=-Hh*.37,jq=seg(.89,.946,st),dY=ps==='jump'?lap*jq-Math.sin(jq*Math.PI)*Hh*.2:ps==='sleep'?lap:0,rot=0,sitting=ps==='sit'&&fr>=25&&fr<=29;
      htrack.style.transform='translate3d('+(-cam*Sp).toFixed(1)+'px,0,0)';
      if(fr!==hst.fr){hst.fr=fr;hspr.style.backgroundPosition=((fr%8)/7*100).toFixed(2)+'% '+(Math.floor(fr/8)/4*100).toFixed(2)+'%'}
      if(ps!==hpose){hpose=ps;hspr.style.opacity=ps==='sleep'?0:1;hslp.style.opacity=ps==='sleep'?1:0}
      hdog.style.transform='translate3d('+(dX*Sp).toFixed(1)+'px,'+dY.toFixed(1)+'px,0)';
      var hb=function(x){return 'translate3d('+(x*Sp).toFixed(1)+'px,0,0)'};
      if(!hst.ms){hst.ms=[$('#hE .hms'),$('#hM .hms'),$('#hT .hms')];hst.mf=[-1,-1,-1]}
      var wk=function(x,n){return (Math.floor(hst.hph*n)%n+n)%n},tw=[0,1,8,9],tf,tq0=seg(.645,.69,st);
      tf=st<.645?tw[wk(dX,4)]:st<.69?Math.min(7,2+Math.floor(tq0*6)):st<.72?7:tw[wk(dX,4)];
      var mfr=[wk(dX,9),wk(dX,9),tf];for(var hi=0;hi<3;hi++){if(mfr[hi]!==hst.mf[hi]){hst.mf[hi]=mfr[hi];hst.ms[hi].style.backgroundPositionX=(mfr[hi]/9*100).toFixed(2)+'%'}}
      hst.E.style.transform=hb(eX);hst.M.style.transform=hb(mX);hst.T.style.transform=hb(tX);hst.C.style.transform='translate3d('+(cX*Sp).toFixed(1)+'px,0,0)';
      var mxo=sitting?Hh*.2:Hh*.31,myo=(sitting?-Hh*.45:ps==='run'?-Hh*.37:-Hh*.385)+dY;
      /* bone */
      var bx,by,br=0,bo=1,bg=-Hh*.025;
      if(st<.035){bo=0;bx=0;by=0}
      else if(st<.07){var bq=seg(.035,.07,st),b0=(.75+.15*kf([[0,0],[.087,.72]],.035))*Sp+Hh*.2,b1=.72*Sp+mxo;bx=b0+(b1-b0)*bq;by=-Hh*.66*(1-bq*bq)+bg;br=bq*200}
      else if(st<.135){bx=.72*Sp+mxo;by=bg;br=200}
      else if(st<.335){bx=dX*Sp+mxo;by=myo;br=8}
      else{var bd=seg(.335,.352,st);bx=2.22*Sp+mxo;by=-Hh*.5+(bg+Hh*.5)*bd;br=8+bd*30}
      hbone.style.opacity=bo;hbone.style.transform='translate3d('+bx.toFixed(1)+'px,'+by.toFixed(1)+'px,0) rotate('+br.toFixed(0)+'deg)';
      /* leash: clips on while the dog sits, stays for the walk, unclips and swings back to the hand */
      var lon=seg(.345,.365,st),loff=seg(.515,.54,st),lo=lon*(1-seg(.54,.556,st));hleash.style.opacity=lo.toFixed(2);hclip.style.opacity=lo.toFixed(2);
      if(lo>0){var LHd=[[.201,.471],[.197,.491],[.129,.477],[.211,.518],[.201,.502],[.204,.507],[.208,.514],[.167,.466],[.125,.473],[.163,.471]][hst.mf?hst.mf[1]:0]||[.2,.48],hx=mX*Sp+Hh*LHd[0],hy=-Hh*(LHd[1]-.017),nx0=dX*Sp+(sitting?Hh*.09:Hh*.17),ny0=(sitting?-Hh*.34:-Hh*.3)+dY,nx=nx0+(hx+Hh*.02-nx0)*loff,ny=ny0+(hy+Hh*.3-ny0)*loff;
        hleash.setAttribute('d','M'+hx.toFixed(1)+' '+hy.toFixed(1)+' Q'+((hx+nx)/2).toFixed(1)+' '+(Math.max(hy,ny)+Hh*.15*(1-loff)).toFixed(1)+' '+nx.toFixed(1)+' '+ny.toFixed(1));hclip.setAttribute('cx',nx.toFixed(1));hclip.setAttribute('cy',ny.toFixed(1))}
      /* ball */
      var tq=seg(.671,.765,st),thx=tX*Sp+Hh*.36,thy=-Hh*.74,bxx,byy;
      if(st<.671){bxx=thx;byy=thy}else if(st<.765){var t0x=(3.752+.15*4.12)*Sp+Hh*.36,cxb=5.32*Sp+mxo;bxx=t0x+(cxb-t0x)*tq;byy=thy+(-Hh*.36-thy)*tq-Math.sin(tq*Math.PI)*Hh*.55}else{bxx=dX*Sp+mxo;byy=myo}
      hst.ball.style.opacity=st>=.93||st<.668?0:1;hst.ball.style.transform='translate3d('+bxx.toFixed(1)+'px,'+byy.toFixed(1)+'px,0)';}
    var k=seg(.9,1,hp);hframe.style.transform='scale('+(1-k*.08).toFixed(4)+')';hframe.style.borderRadius=(k*34).toFixed(1)+'px';
    if(glok&&tex[0]&&started){var ia=tex[idx]?idx:0,ib=tex[idx+1]?idx+1:ia;
      gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,tex[ia]);gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,tex[ib]);
      gl.uniform2f(U.res,canvas.width,canvas.height);gl.uniform2f(U.s0,tsize[ia][0],tsize[ia][1]);gl.uniform2f(U.s1,tsize[ib][0],tsize[ib][1]);gl.uniform2f(U.fy,heroFy[ia],heroFy[ib]);
      gl.uniform2f(U.mouse,reduce?.5:mouse.x,reduce?.5:mouse.y);gl.uniform1f(U.pr,f);gl.uniform1f(U.time,reduce?0:t);gl.uniform1f(U.vel,S.svel);gl.drawArrays(gl.TRIANGLE_STRIP,0,4);
    }else if(started){var fi=P<.5?0:P<1.5?1:2;if(hfall._i!==fi){hfall._i=fi;hfall.style.backgroundImage='url('+heroSrc[fi]+')'}}
  }
  if(mq){var w1=mq.scrollWidth/6||1,mx=(t*36+S.sy*.45)%w1;mq.style.transform='translate3d('+(-mx).toFixed(1)+'px,0,0) skewX('+(S.svel*-6).toFixed(2)+'deg)'}
  if(qEl){var mp=clamp((S.sy+vh*.8-M.q.t)/(M.q.h+vh*.35)),lit=Math.round(mp*qWords.length);for(var i=0;i<qWords.length;i++){var on=i<lit;if(qWords[i]._on!==on){qWords[i]._on=on;qWords[i].classList.toggle('lit',on)}}}
  for(var j=0;j<pars.length;j++){var m=M.par[j],pp=clamp((S.sy+vh-m.t)/(vh+m.h));pars[j].style.transform='translate3d(0,'+((pp-.5)*m.k).toFixed(2)+'%,0)'}
  if(bigs.length>1&&vw>900){var b0=M.big[0],b1=M.big[1],ov=clamp((S.sy-b0.t)/(b1.t-b0.t+1));bigs[0].style.transform='scale('+(1-ov*.05).toFixed(4)+')';bigs[0].style.filter='brightness('+(1-ov*.45).toFixed(3)+')'}
  if(strip){if(!film.drag){film.x-=(.5+Math.abs(S.svel)*5);film.x+=film.v;film.v*=.93}if(film.w){if(film.x<-film.w)film.x+=film.w;if(film.x>0)film.x-=film.w}strip.style.transform='translate3d('+film.x.toFixed(1)+'px,0,0)'}
  if(rfloat&&fine){var ox=rf.x;rf.x=lerp(rf.x,mouse.px,.1);rf.y=lerp(rf.y,mouse.py,.1);rf.rot=lerp(rf.rot,clamp((rf.x-ox)*.6,-10,10),.2);rfloat.style.transform='translate3d('+rf.x.toFixed(1)+'px,'+rf.y.toFixed(1)+'px,0) rotate('+rf.rot.toFixed(2)+'deg) scale('+(rf.on?1:.7)+')'}
  if(ctaWord){var cp=clamp((S.sy+vh-M.cta.t)/(vh+M.cta.h));ctaWord.style.transform='translate3d('+(-cp*30).toFixed(2)+'%,0,0)'}
  if(bgw)bgw.style.transform='translate3d('+(-S.sy*.25).toFixed(1)+'px,0,0)';
  if(reel&&M.reel){var np=panels.length-1,rp=clamp((S.sy-M.reel.t)/(M.reel.h-vh)),span=Math.max(0,M.reel.w-vw),tx=-rp*span,act=0;
    rtrack.style.transform='translate3d('+tx.toFixed(1)+'px,0,0) skewX('+(S.svel*-2).toFixed(2)+'deg)';
    for(var q=0;q<panels.length;q++){var pn=panels[q],rel=(pn.offsetLeft+pn.offsetWidth/2+tx-vw/2)/vw;if(Math.abs(rel)<.5)act=q;var pic=pn._pic||(pn._pic=pn.querySelector('.pic')),dg=pn._dg||(pn._dg=pn.querySelector('.pdog'));
      if(pic)pic.style.transform='translate3d('+(rel*-5).toFixed(2)+'%,0,0) scale(1.12)';if(Math.abs(rel)<.25&&!pn._pk){pn._pk=1;var fl=pn.querySelector('.flip');if(fl)fl.classList.add('peek')}if(dg)dg.style.transform='translate3d('+(rel*(+dg.dataset.px)).toFixed(1)+'px,'+(Math.sin(t*1.4+q)*6).toFixed(1)+'px,0) rotate('+(rel*-10).toFixed(2)+'deg)'}
    if(rcnt)rcnt.textContent='0'+(act+1)}
  if(maniDog&&M.q){var md=clamp((S.sy+vh*.8-M.q.t)/(M.q.h+vh*.35));maniDog.style.transform='translate3d(0,'+((md-.5)*-60).toFixed(1)+'px,0) rotate('+((md-.5)*-6).toFixed(2)+'deg)'}
  if(rdog){var dy=S.y-lastY;lastY=S.y;spd=lerp(spd,Math.abs(dy),.25);if(dy>.5)flip=-1;else if(dy<-.5)flip=1;
    var pg=clamp(S.y/M.doc),nf,slp=false;rph+=Math.abs(dy);
    if(spd>16){nf=9+Math.floor(rph/42)%6;idleAt=now}else if(spd>.6){nf=Math.floor(rph/16)%8;idleAt=now}else if(now-idleAt>6000){slp=true;nf=27}else if(now-idleAt>700)nf=27;else nf=24;
    if(nf!==rfr){rfr=nf;rspr.style.backgroundPosition=((nf%8)/7*100).toFixed(2)+'% '+(Math.floor(nf/8)/4*100).toFixed(2)+'%'}
    if(slp!==rdog._s){rdog._s=slp;rspr.style.opacity=slp?0:1;rslp.style.opacity=slp?1:0}
    rdog.style.transform='translate3d('+(pg*(vw-84)).toFixed(1)+'px,0,0) scaleX('+flip+')';rfill.style.transform='scaleX('+pg.toFixed(4)+')'}
}

/* flip cards */
$$('.flip').forEach(function(f){f.addEventListener('click',function(){var o=f.classList.toggle('flipped');f.classList.remove('peek');f.setAttribute('aria-pressed',o)})});
/* reel: sideways wheel and swipe drive the same scroll */
var rst=$('.rstage');
if(rst&&reel){var jump=function(d){window.scrollTo({top:(window.scrollY||0)+d,behavior:'instant'})},ratio=function(){var sp=Math.max(1,M.reel.w-S.vw);return (M.reel.h-S.vh)/sp},
  pinned=function(){var y=window.scrollY||0;return y>=M.reel.t-2&&y<=M.reel.t+M.reel.h-S.vh+2};
  rst.addEventListener('wheel',function(e){if(Math.abs(e.deltaX)>Math.abs(e.deltaY)&&M.reel){e.preventDefault();jump(e.deltaX*ratio())}},{passive:false});
  var tc=null,iv=0,raf=0;
  rst.addEventListener('touchstart',function(e){cancelAnimationFrame(raf);var p=e.touches[0];tc={x:p.clientX,y:p.clientY,lx:p.clientX,lt:e.timeStamp,dir:0}},{passive:true});
  rst.addEventListener('touchmove',function(e){if(!tc||!M.reel)return;var p=e.touches[0],dx=p.clientX-tc.x,dy=p.clientY-tc.y;
    if(!tc.dir){if(Math.abs(dx)>8&&Math.abs(dx)>Math.abs(dy)*1.2)tc.dir=1;else if(Math.abs(dy)>8)tc.dir=2}
    if(tc.dir===1){e.preventDefault();var step=p.clientX-tc.lx,dt=Math.max(1,e.timeStamp-tc.lt);iv=step/dt;tc.lx=p.clientX;tc.lt=e.timeStamp;
      if(!pinned()){var y=window.scrollY||0;jump(y<M.reel.t?M.reel.t-y:(M.reel.t+M.reel.h-S.vh)-y)}jump(-step*ratio())}},{passive:false});
  rst.addEventListener('touchend',function(){if(!tc||tc.dir!==1){tc=null;return}tc=null;var v=iv*16;(function glide(){if(Math.abs(v)<.4)return;jump(-v*ratio());v*=.93;raf=requestAnimationFrame(glide)})()},{passive:true});
  rst.addEventListener('click',function(e){if(tc&&tc.dir===1)e.preventDefault()},true)}
/* theme */
var tgl=$('#tgl');if(tgl)tgl.addEventListener('click',function(){var l=root.dataset.theme==='light';if(l)delete root.dataset.theme;else root.dataset.theme='light';var cs=$('meta[name="color-scheme"]'),tc=$('meta[name="theme-color"]');if(cs)cs.content=l?'dark':'light';if(tc)tc.content=l?'#0a0a0a':'#fdf5e8';try{localStorage.setItem('wf-theme',l?'dark':'light')}catch(e){}});
measure();window.addEventListener('resize',onResize);window.addEventListener('orientationchange',function(){setTimeout(measure,350)});window.addEventListener('load',measure);setTimeout(measure,1200);setTimeout(measure,3200);
requestAnimationFrame(frame);
})();

